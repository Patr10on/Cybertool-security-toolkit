package com.p4tron.cybertool;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.text.InputType;
import android.os.AsyncTask;
import android.content.Intent;
import android.net.Uri;
import java.util.Random;
import java.security.MessageDigest;
import java.net.*;
import java.io.*;
import javax.net.ssl.*;
import java.security.cert.X509Certificate;
import java.util.*;

public class MainActivity extends Activity {
    
    private LinearLayout mainLayout;
    private ScrollView scrollView;
    private TextView titleText;
    private int currentSection = 0;
    private ProgressBar loadingBar;
    
    // Colors
    private final int BG_BLACK = Color.parseColor("#000000");
    private final int MATRIX_GREEN = Color.parseColor("#00FF41");
    private final int MATRIX_DARK_GREEN = Color.parseColor("#008F11");
    private final int CARD_BG = Color.parseColor("#1A1A1A");
    private final int CYBER_BLUE = Color.parseColor("#00D9FF");
    private final int DANGER_RED = Color.parseColor("#FF0055");
    private final int WARNING_ORANGE = Color.parseColor("#FF9500");
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(BG_BLACK);
        
        createHeader(container);
        
        scrollView = new ScrollView(this);
        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(20, 20, 20, 20);
        scrollView.addView(mainLayout);
        container.addView(scrollView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f
        ));
        
        createBottomNav(container);
        showDashboard();
        
        setContentView(container);
    }
    
    private void createHeader(LinearLayout parent) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(Color.parseColor("#0D0208"));
        header.setPadding(20, 30, 20, 20);
        
        titleText = new TextView(this);
        titleText.setText("⚡ P4TRON CYBERTOOL");
        titleText.setTextColor(MATRIX_GREEN);
        titleText.setTextSize(24);
        titleText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        header.addView(titleText);
        
        TextView subtitle = new TextView(this);
        subtitle.setText("Advanced Security Toolkit v1.0");
        subtitle.setTextColor(MATRIX_GREEN);
        subtitle.setTextSize(12);
        subtitle.setTypeface(Typeface.MONOSPACE);
        subtitle.setAlpha(0.7f);
        header.addView(subtitle);
        
        parent.addView(header);
    }
    
    private void createBottomNav(LinearLayout parent) {
        LinearLayout navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setBackgroundColor(Color.parseColor("#0D0208"));
        navBar.setPadding(5, 10, 5, 10);
        
        String[] navItems = {"🏠\nHome", "🌐\nNet", "🔒\nWeb", "🔐\nPass", "👤\nDev"};
        
        for (int i = 0; i < navItems.length; i++) {
            final int section = i;
            Button btn = new Button(this);
            btn.setText(navItems[i]);
            btn.setTextColor(MATRIX_GREEN);
            btn.setTextSize(10);
            btn.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            btn.setBackgroundColor(Color.TRANSPARENT);
            btn.setAllCaps(false);
            
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
            );
            params.setMargins(2, 0, 2, 0);
            btn.setLayoutParams(params);
            
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentSection = section;
                    updateContent();
                }
            });
            
            navBar.addView(btn);
        }
        
        parent.addView(navBar);
    }
    
    private void updateContent() {
        mainLayout.removeAllViews();
        
        switch(currentSection) {
            case 0: showDashboard(); break;
            case 1: showNetworkTools(); break;
            case 2: showWebSecurity(); break;
            case 3: showPasswordTools(); break;
            case 4: showDeveloperInfo(); break;
        }
    }
    
    private void showDashboard() {
        titleText.setText("⚡ P4TRON DASHBOARD");
        
        addCard("⚡ WELCOME HACKER ⚡", 
                "Professional cybersecurity toolkit.\n\n⚠ LEGAL NOTICE: Only use on authorized systems!\nUnauthorized access is illegal.",
                MATRIX_GREEN);
        
        LinearLayout statsCard = createCardLayout();
        TextView statsTitle = createTextView("📊 SYSTEM STATUS", 16, true);
        statsCard.addView(statsTitle);
        
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.setPadding(0, 20, 0, 0);
        
        addStatItem(statsRow, "TOOLS", "12", CYBER_BLUE);
        addStatItem(statsRow, "READY", "✓", MATRIX_GREEN);
        addStatItem(statsRow, "STATUS", "OK", MATRIX_GREEN);
        
        statsCard.addView(statsRow);
        mainLayout.addView(statsCard);
        
        addSectionTitle(">> QUICK ACCESS");
        
        addToolCard("🌐 NETWORK TOOLS", "Real Port Scanner, DNS, Ping");
        addToolCard("🔒 WEB SECURITY", "SSL Check, Headers, Domain Info");
        addToolCard("🔐 PASSWORD SUITE", "Generator, Checker, Hash Tools");
        addToolCard("👤 DEVELOPER", "Credits & Information");
    }
    
    private void showNetworkTools() {
        titleText.setText("🌐 NETWORK TOOLS");
        
        addSectionTitle(">> NETWORK RECONNAISSANCE");
        
        addClickableCard("🔍 PORT SCANNER", "Real port scanning (TCP)", new Runnable() {
            @Override
            public void run() {
                showRealPortScanner();
            }
        });
        
        addClickableCard("🌐 DNS LOOKUP", "Real DNS resolution", new Runnable() {
            @Override
            public void run() {
                showRealDNSLookup();
            }
        });
        
        addClickableCard("📶 PING TEST", "Real ICMP/TCP ping", new Runnable() {
            @Override
            public void run() {
                showRealPing();
            }
        });
        
        addClickableCard("📋 WHOIS LOOKUP", "Domain registration info", new Runnable() {
            @Override
            public void run() {
                showWhoisInfo();
            }
        });
        
        addClickableCard("🔎 IP LOOKUP", "Get your public IP", new Runnable() {
            @Override
            public void run() {
                showIPLookup();
            }
        });
    }
    
    private void showWebSecurity() {
        titleText.setText("🔒 WEB SECURITY");
        
        addSectionTitle(">> WEB ANALYSIS");
        
        addClickableCard("🔒 SSL/TLS CHECKER", "Real certificate validation", new Runnable() {
            @Override
            public void run() {
                showRealSSLChecker();
            }
        });
        
        addClickableCard("📄 HTTP HEADERS", "Real header analysis", new Runnable() {
            @Override
            public void run() {
                showHTTPHeaders();
            }
        });
        
        addClickableCard("🌐 HTTP STATUS", "Check website status", new Runnable() {
            @Override
            public void run() {
                showHTTPStatus();
            }
        });
        
        addClickableCard("🔗 URL PARSER", "Parse and analyze URLs", new Runnable() {
            @Override
            public void run() {
                showURLParser();
            }
        });
    }
    
    private void showPasswordTools() {
        titleText.setText("🔐 PASSWORD SUITE");
        
        addSectionTitle(">> PASSWORD SECURITY");
        
        addClickableCard("🔐 PASSWORD GENERATOR", "Cryptographically secure", new Runnable() {
            @Override
            public void run() {
                showPasswordGenerator();
            }
        });
        
        addClickableCard("💪 PASSWORD STRENGTH", "Advanced analysis", new Runnable() {
            @Override
            public void run() {
                showPasswordChecker();
            }
        });
        
        addClickableCard("⚙️ HASH GENERATOR", "MD5, SHA-256, SHA-512", new Runnable() {
            @Override
            public void run() {
                showHashGenerator();
            }
        });
        
        addClickableCard("🔢 BASE64 ENCODER", "Encode/Decode Base64", new Runnable() {
            @Override
            public void run() {
                showBase64Tool();
            }
        });
    }
    
    private void showDeveloperInfo() {
        titleText.setText("👤 DEVELOPER INFO");
        
        addSectionTitle(">> CREDITS");
        
        LinearLayout devCard = createCardLayout();
        
        TextView devTitle = createTextView("🎯 P4TRON CYBERTOOL", 18, true);
        devTitle.setTextColor(CYBER_BLUE);
        devCard.addView(devTitle);
        
        addSpace(devCard, 10);
        
        TextView version = createTextView("Version: 1.0.0 (Production)", 12, false);
        version.setTextColor(MATRIX_GREEN);
        devCard.addView(version);
        
        addSpace(devCard, 20);
        
        TextView devHeader = createTextView("💻 DEVELOPED BY:", 14, true);
        devHeader.setTextColor(MATRIX_GREEN);
        devCard.addView(devHeader);
        
        addSpace(devCard, 10);
        
        TextView devName = createTextView("P4TRON", 16, true);
        devName.setTextColor(CYBER_BLUE);
        devCard.addView(devName);
        
        TextView devRole = createTextView("Security Researcher & Developer", 12, false);
        devRole.setTextColor(MATRIX_GREEN);
        devRole.setAlpha(0.8f);
        devCard.addView(devRole);
        
        addSpace(devCard, 20);
        
        TextView featuresTitle = createTextView("✨ FEATURES:", 14, true);
        featuresTitle.setTextColor(MATRIX_GREEN);
        devCard.addView(featuresTitle);
        
        addSpace(devCard, 10);
        
        String[] features = {
            "• Real Port Scanner (TCP)",
            "• Real DNS Resolver",
            "• Real SSL/TLS Checker",
            "• Real HTTP Headers",
            "• Advanced Password Tools",
            "• Cryptographic Hashing",
            "• Network Diagnostics"
        };
        
        for (String feature : features) {
            TextView featItem = createTextView(feature, 11, false);
            featItem.setTextColor(MATRIX_GREEN);
            featItem.setAlpha(0.9f);
            devCard.addView(featItem);
        }
        
        addSpace(devCard, 20);
        
        TextView disclaimer = createTextView("⚠ LEGAL DISCLAIMER:", 12, true);
        disclaimer.setTextColor(WARNING_ORANGE);
        devCard.addView(disclaimer);
        
        TextView disclaimerText = createTextView(
            "This tool is for educational and authorized testing only. " +
            "Unauthorized access to computer systems is illegal. " +
            "The developer is not responsible for misuse.",
            11, false
        );
        disclaimerText.setTextColor(WARNING_ORANGE);
        disclaimerText.setAlpha(0.8f);
        devCard.addView(disclaimerText);
        
        addSpace(devCard, 20);
        
        TextView copyright = createTextView("© 2025 P4TRON. All rights reserved.", 10, false);
        copyright.setTextColor(MATRIX_GREEN);
        copyright.setAlpha(0.6f);
        copyright.setGravity(Gravity.CENTER);
        devCard.addView(copyright);
        
        mainLayout.addView(devCard);
        
        addSpace(mainLayout, 20);
        
        Button githubBtn = new Button(this);
        githubBtn.setText("⭐ STAR ON GITHUB");
        githubBtn.setTextColor(BG_BLACK);
        githubBtn.setBackgroundColor(MATRIX_GREEN);
        githubBtn.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        githubBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("https://github.com/patr10on"));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "GitHub: p4tron", Toast.LENGTH_LONG).show();
                }
            }
        });
        mainLayout.addView(githubBtn);
    }
    
    // REAL NETWORK TOOLS
    
    private void showRealPortScanner() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("🔍 REAL PORT SCANNER");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText ipInput = new EditText(this);
        ipInput.setHint("Host (e.g., google.com)");
        ipInput.setText("google.com");
        ipInput.setTextColor(MATRIX_GREEN);
        ipInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(ipInput);
        
        final EditText portsInput = new EditText(this);
        portsInput.setHint("Ports (e.g., 80,443,8080)");
        portsInput.setText("80,443,8080,22");
        portsInput.setTextColor(MATRIX_GREEN);
        portsInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(portsInput);
        
        TextView warning = createTextView("⚠ Only scan authorized hosts!", 10, false);
        warning.setTextColor(WARNING_ORANGE);
        layout.addView(warning);
        
        builder.setView(layout);
        
        builder.setPositiveButton("SCAN", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String host = ipInput.getText().toString().trim();
                String ports = portsInput.getText().toString().trim();
                
                if (host.isEmpty()) {
                    showMessage("Error", "Please enter a host");
                    return;
                }
                
                new PortScanTask(host, ports).execute();
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private class PortScanTask extends AsyncTask<Void, String, String> {
        private String host;
        private String[] ports;
        private android.app.ProgressDialog progressDialog;
        
        public PortScanTask(String host, String portsStr) {
            this.host = host;
            this.ports = portsStr.split(",");
        }
        
        @Override
        protected void onPreExecute() {
            progressDialog = new android.app.ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Scanning ports...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        
        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder result = new StringBuilder();
            result.append("PORT SCAN RESULTS\n");
            result.append("Host: ").append(host).append("\n\n");
            
            for (String portStr : ports) {
                try {
                    int port = Integer.parseInt(portStr.trim());
                    Socket socket = new Socket();
                    socket.connect(new InetSocketAddress(host, port), 2000);
                    socket.close();
                    result.append("✓ Port ").append(port).append(" - OPEN\n");
                } catch (Exception e) {
                    result.append("✗ Port ").append(portStr.trim()).append(" - CLOSED\n");
                }
            }
            
            return result.toString();
        }
        
        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            showMessage("Scan Complete", result);
        }
    }
    
    private void showRealDNSLookup() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("🌐 REAL DNS LOOKUP");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText domainInput = new EditText(this);
        domainInput.setHint("Domain (e.g., google.com)");
        domainInput.setText("google.com");
        domainInput.setTextColor(MATRIX_GREEN);
        domainInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(domainInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("LOOKUP", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String domain = domainInput.getText().toString().trim();
                
                if (domain.isEmpty()) {
                    showMessage("Error", "Please enter a domain");
                    return;
                }
                
                new DNSLookupTask(domain).execute();
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private class DNSLookupTask extends AsyncTask<Void, Void, String> {
        private String domain;
        private android.app.ProgressDialog progressDialog;
        
        public DNSLookupTask(String domain) {
            this.domain = domain;
        }
        
        @Override
        protected void onPreExecute() {
            progressDialog = new android.app.ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Resolving DNS...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        
        @Override
        protected String doInBackground(Void... voids) {
            try {
                InetAddress[] addresses = InetAddress.getAllByName(domain);
                StringBuilder result = new StringBuilder();
                result.append("DNS LOOKUP RESULTS\n");
                result.append("Domain: ").append(domain).append("\n\n");
                
                for (InetAddress addr : addresses) {
                    result.append("IP: ").append(addr.getHostAddress()).append("\n");
                    result.append("Hostname: ").append(addr.getHostName()).append("\n");
                    result.append("Canonical: ").append(addr.getCanonicalHostName()).append("\n\n");
                }
                
                return result.toString();
            } catch (Exception e) {
                return "Error: " + e.getMessage();
            }
        }
        
        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            showMessage("DNS Lookup", result);
        }
    }
    
    private void showRealPing() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("📶 REAL PING TEST");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText hostInput = new EditText(this);
        hostInput.setHint("Host (e.g., 8.8.8.8)");
        hostInput.setText("8.8.8.8");
        hostInput.setTextColor(MATRIX_GREEN);
        hostInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(hostInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("PING", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String host = hostInput.getText().toString().trim();
                
                if (host.isEmpty()) {
                    showMessage("Error", "Please enter a host");
                    return;
                }
                
                new PingTask(host).execute();
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private class PingTask extends AsyncTask<Void, Void, String> {
        private String host;
        private android.app.ProgressDialog progressDialog;
        
        public PingTask(String host) {
            this.host = host;
        }
        
        @Override
        protected void onPreExecute() {
            progressDialog = new android.app.ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Pinging host...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        
        @Override
        protected String doInBackground(Void... voids) {
            try {
                InetAddress address = InetAddress.getByName(host);
                StringBuilder result = new StringBuilder();
                result.append("PING RESULTS\n");
                result.append("Host: ").append(host).append("\n");
                result.append("IP: ").append(address.getHostAddress()).append("\n\n");
                
                int count = 4;
                int success = 0;
                long totalTime = 0;
                
                for (int i = 0; i < count; i++) {
                    long start = System.currentTimeMillis();
                    boolean reachable = address.isReachable(3000);
                    long time = System.currentTimeMillis() - start;
                    
                    if (reachable) {
                        success++;
                        totalTime += time;
                        result.append("✓ Reply: time=").append(time).append("ms\n");
                    } else {
                        result.append("✗ Request timeout\n");
                    }
                }
                
                result.append("\nStatistics:\n");
                result.append("Packets: Sent=").append(count).append(", Received=").append(success);
                result.append(", Lost=").append(count - success).append("\n");
                
                if (success > 0) {
                    result.append("Average time: ").append(totalTime / success).append("ms\n");
                }
                
                return result.toString();
            } catch (Exception e) {
                return "Error: " + e.getMessage();
            }
        }
        
        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            showMessage("Ping Complete", result);
        }
    }
    
    private void showRealSSLChecker() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("🔒 REAL SSL/TLS CHECKER");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText domainInput = new EditText(this);
        domainInput.setHint("Domain (e.g., google.com)");
        domainInput.setText("google.com");
        domainInput.setTextColor(MATRIX_GREEN);
        domainInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(domainInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("CHECK", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String domain = domainInput.getText().toString().trim();
                
                if (domain.isEmpty()) {
                    showMessage("Error", "Please enter a domain");
                    return;
                }
                
                new SSLCheckTask(domain).execute();
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private class SSLCheckTask extends AsyncTask<Void, Void, String> {
        private String domain;
        private android.app.ProgressDialog progressDialog;
        
        public SSLCheckTask(String domain) {
            this.domain = domain;
        }
        
        @Override
        protected void onPreExecute() {
            progressDialog = new android.app.ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Checking SSL...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        
        @Override
        protected String doInBackground(Void... voids) {
            try {
                SSLContext context = SSLContext.getInstance("TLS");
                context.init(null, null, null);
                SSLSocketFactory factory = context.getSocketFactory();
                SSLSocket socket = (SSLSocket) factory.createSocket(domain, 443);
                socket.startHandshake();
                
                SSLSession session = socket.getSession();
                X509Certificate[] certs = (X509Certificate[]) session.getPeerCertificates();
                X509Certificate cert = certs[0];
                
                StringBuilder result = new StringBuilder();
                result.append("SSL/TLS CERTIFICATE\n\n");
                result.append("✓ Status: Valid & Trusted\n\n");
                result.append("Subject: ").append(cert.getSubjectDN()).append("\n\n");
                result.append("Issuer: ").append(cert.getIssuerDN()).append("\n\n");
                result.append("Valid From: ").append(cert.getNotBefore()).append("\n");
                result.append("Valid Until: ").append(cert.getNotAfter()).append("\n\n");
                result.append("Serial: ").append(cert.getSerialNumber()).append("\n");
                result.append("Protocol: ").append(session.getProtocol()).append("\n");
                result.append("Cipher: ").append(session.getCipherSuite()).append("\n");
                
                socket.close();
                return result.toString();
            } catch (Exception e) {
                return "Error: " + e.getMessage();
            }
        }
        
        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            showMessage("SSL Check", result);
        }
    }
    
    private void showHTTPHeaders() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("📄 HTTP HEADERS");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText urlInput = new EditText(this);
        urlInput.setHint("URL (https://example.com)");
        urlInput.setText("https://google.com");
        urlInput.setTextColor(MATRIX_GREEN);
        urlInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(urlInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("FETCH", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String url = urlInput.getText().toString().trim();
                
                if (url.isEmpty()) {
                    showMessage("Error", "Please enter a URL");
                    return;
                }
                
                new HTTPHeadersTask(url).execute();
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private class HTTPHeadersTask extends AsyncTask<Void, Void, String> {
        private String urlStr;
        private android.app.ProgressDialog progressDialog;
        
        public HTTPHeadersTask(String url) {
            this.urlStr = url;
        }
        
        @Override
        protected void onPreExecute() {
            progressDialog = new android.app.ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Fetching headers...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        
        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.connect();
                
                StringBuilder result = new StringBuilder();
                result.append("HTTP RESPONSE HEADERS\n\n");
                result.append("Status: ").append(conn.getResponseCode())
                      .append(" ").append(conn.getResponseMessage()).append("\n\n");
                
                Map<String, List<String>> headers = conn.getHeaderFields();
                for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
                    String key = entry.getKey();
                    if (key != null) {
                        for (String value : entry.getValue()) {
                            result.append(key).append(": ").append(value).append("\n");
                        }
                    }
                }
                
                conn.disconnect();
                return result.toString();
            } catch (Exception e) {
                return "Error: " + e.getMessage();
            }
        }
        
        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            showMessage("Headers", result);
        }
    }
    
    private void showHTTPStatus() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("🌐 HTTP STATUS CHECK");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText urlInput = new EditText(this);
        urlInput.setHint("URL (https://example.com)");
        urlInput.setText("https://google.com");
        urlInput.setTextColor(MATRIX_GREEN);
        urlInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(urlInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("CHECK", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String url = urlInput.getText().toString().trim();
                if (!url.isEmpty()) {
                    new HTTPStatusTask(url).execute();
                }
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private class HTTPStatusTask extends AsyncTask<Void, Void, String> {
        private String urlStr;
        private android.app.ProgressDialog progressDialog;
        
        public HTTPStatusTask(String url) {
            this.urlStr = url;
        }
        
        @Override
        protected void onPreExecute() {
            progressDialog = new android.app.ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Checking status...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
        
        @Override
        protected String doInBackground(Void... voids) {
            try {
                long start = System.currentTimeMillis();
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.connect();
                long time = System.currentTimeMillis() - start;
                
                int code = conn.getResponseCode();
                String message = conn.getResponseMessage();
                
                StringBuilder result = new StringBuilder();
                result.append("HTTP STATUS CHECK\n\n");
                result.append("URL: ").append(urlStr).append("\n\n");
                result.append("Status Code: ").append(code).append("\n");
                result.append("Message: ").append(message).append("\n");
                result.append("Response Time: ").append(time).append("ms\n\n");
                
                String status = (code >= 200 && code < 300) ? "✓ OK" :
                               (code >= 300 && code < 400) ? "⚠ Redirect" :
                               (code >= 400 && code < 500) ? "✗ Client Error" :
                               "✗ Server Error";
                
                result.append("Status: ").append(status);
                
                conn.disconnect();
                return result.toString();
            } catch (Exception e) {
                return "Error: " + e.getMessage();
            }
        }
        
        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            showMessage("Status Check", result);
        }
    }
    
    private void showURLParser() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("🔗 URL PARSER");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText urlInput = new EditText(this);
        urlInput.setHint("URL to parse");
        urlInput.setText("https://example.com:8080/path?key=value#section");
        urlInput.setTextColor(MATRIX_GREEN);
        urlInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(urlInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("PARSE", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                try {
                    String urlStr = urlInput.getText().toString().trim();
                    URL url = new URL(urlStr);
                    
                    StringBuilder result = new StringBuilder();
                    result.append("URL COMPONENTS\n\n");
                    result.append("Protocol: ").append(url.getProtocol()).append("\n");
                    result.append("Host: ").append(url.getHost()).append("\n");
                    result.append("Port: ").append(url.getPort() != -1 ? url.getPort() : "default").append("\n");
                    result.append("Path: ").append(url.getPath()).append("\n");
                    result.append("Query: ").append(url.getQuery() != null ? url.getQuery() : "none").append("\n");
                    result.append("Fragment: ").append(url.getRef() != null ? url.getRef() : "none").append("\n");
                    
                    showMessage("URL Parsed", result.toString());
                } catch (Exception e) {
                    showMessage("Error", "Invalid URL: " + e.getMessage());
                }
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private void showWhoisInfo() {
        showMessage("WHOIS Info", 
            "Domain: example.com\n\n" +
            "Registrar: GoDaddy\n" +
            "Status: Active\n" +
            "Created: 1995-08-14\n" +
            "Expires: 2025-08-13\n\n" +
            "Note: Full WHOIS requires API");
    }
    
    private void showIPLookup() {
        new AsyncTask<Void, Void, String>() {
            android.app.ProgressDialog pd;
            
            @Override
            protected void onPreExecute() {
                pd = new android.app.ProgressDialog(MainActivity.this);
                pd.setMessage("Getting IP...");
                pd.show();
            }
            
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL("https://api.ipify.org");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String ip = reader.readLine();
                    reader.close();
                    return "Your Public IP:\n\n" + ip;
                } catch (Exception e) {
                    return "Error: " + e.getMessage();
                }
            }
            
            @Override
            protected void onPostExecute(String result) {
                pd.dismiss();
                showMessage("IP Lookup", result);
            }
        }.execute();
    }
    
    // PASSWORD TOOLS (Keep existing implementations)
    
    private void showPasswordGenerator() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("🔐 PASSWORD GENERATOR");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        TextView lengthLabel = new TextView(this);
        lengthLabel.setText("Length: 16");
        lengthLabel.setTextColor(MATRIX_GREEN);
        lengthLabel.setTypeface(Typeface.MONOSPACE);
        layout.addView(lengthLabel);
        
        final SeekBar lengthSeek = new SeekBar(this);
        lengthSeek.setMax(24);
        lengthSeek.setProgress(8);
        layout.addView(lengthSeek);
        
        final CheckBox upperCheck = new CheckBox(this);
        upperCheck.setText("Uppercase (A-Z)");
        upperCheck.setTextColor(MATRIX_GREEN);
        upperCheck.setChecked(true);
        layout.addView(upperCheck);
        
        final CheckBox lowerCheck = new CheckBox(this);
        lowerCheck.setText("Lowercase (a-z)");
        lowerCheck.setTextColor(MATRIX_GREEN);
        lowerCheck.setChecked(true);
        layout.addView(lowerCheck);
        
        final CheckBox numCheck = new CheckBox(this);
        numCheck.setText("Numbers (0-9)");
        numCheck.setTextColor(MATRIX_GREEN);
        numCheck.setChecked(true);
        layout.addView(numCheck);
        
        final CheckBox symbolCheck = new CheckBox(this);
        symbolCheck.setText("Symbols (!@#$...)");
        symbolCheck.setTextColor(MATRIX_GREEN);
        symbolCheck.setChecked(true);
        layout.addView(symbolCheck);
        
        builder.setView(layout);
        
        builder.setPositiveButton("GENERATE", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                int length = lengthSeek.getProgress() + 8;
                String chars = "";
                if (upperCheck.isChecked()) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                if (lowerCheck.isChecked()) chars += "abcdefghijklmnopqrstuvwxyz";
                if (numCheck.isChecked()) chars += "0123456789";
                if (symbolCheck.isChecked()) chars += "!@#$%^&*()_+-=[]{}|;:,.<>?";
                
                if (chars.isEmpty()) chars = "abcdefghijklmnopqrstuvwxyz";
                
                java.security.SecureRandom rand = new java.security.SecureRandom();
                StringBuilder password = new StringBuilder();
                for (int i = 0; i < length; i++) {
                    password.append(chars.charAt(rand.nextInt(chars.length())));
                }
                
                showMessage("Generated Password", password.toString());
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private void showPasswordChecker() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("💪 PASSWORD STRENGTH");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText passInput = new EditText(this);
        passInput.setHint("Enter password");
        passInput.setTextColor(MATRIX_GREEN);
        passInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(passInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("CHECK", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String pass = passInput.getText().toString();
                int score = 0;
                
                if (pass.length() >= 8) score++;
                if (pass.length() >= 12) score++;
                if (pass.matches(".*[A-Z].*")) score++;
                if (pass.matches(".*[a-z].*")) score++;
                if (pass.matches(".*[0-9].*")) score++;
                if (pass.matches(".*[^a-zA-Z0-9].*")) score++;
                
                String strength = score >= 5 ? "VERY STRONG ✓" : 
                                score >= 4 ? "STRONG ✓" :
                                score >= 3 ? "MEDIUM ⚠" : "WEAK ✗";
                
                String analysis = "PASSWORD ANALYSIS:\n\n" +
                    "Strength: " + strength + "\n" +
                    "Length: " + pass.length() + " chars\n" +
                    (pass.matches(".*[A-Z].*") ? "✓" : "✗") + " Uppercase\n" +
                    (pass.matches(".*[a-z].*") ? "✓" : "✗") + " Lowercase\n" +
                    (pass.matches(".*[0-9].*") ? "✓" : "✗") + " Numbers\n" +
                    (pass.matches(".*[^a-zA-Z0-9].*") ? "✓" : "✗") + " Symbols";
                    
                showMessage("Strength Check", analysis);
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private void showHashGenerator() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("⚙️ HASH GENERATOR");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText textInput = new EditText(this);
        textInput.setHint("Text to hash");
        textInput.setTextColor(MATRIX_GREEN);
        textInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(textInput);
        
        final String[] algorithms = {"MD5", "SHA-256", "SHA-512"};
        final Spinner algoSpinner = new Spinner(this);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_item, algorithms);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        algoSpinner.setAdapter(adapter);
        layout.addView(algoSpinner);
        
        builder.setView(layout);
        
        builder.setPositiveButton("GENERATE", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String text = textInput.getText().toString();
                String algo = (String) algoSpinner.getSelectedItem();
                String hash = generateHash(text, algo);
                showMessage(algo + " Hash", hash);
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private void showBase64Tool() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("🔢 BASE64 TOOL");
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        
        final EditText textInput = new EditText(this);
        textInput.setHint("Text to encode/decode");
        textInput.setTextColor(MATRIX_GREEN);
        textInput.setHintTextColor(MATRIX_DARK_GREEN);
        layout.addView(textInput);
        
        builder.setView(layout);
        
        builder.setPositiveButton("ENCODE", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                String text = textInput.getText().toString();
                String encoded = android.util.Base64.encodeToString(
                    text.getBytes(), android.util.Base64.NO_WRAP);
                showMessage("Base64 Encoded", encoded);
            }
        });
        
        builder.setNeutralButton("DECODE", new android.content.DialogInterface.OnClickListener() {
            @Override
            public void onClick(android.content.DialogInterface dialog, int which) {
                try {
                    String text = textInput.getText().toString();
                    byte[] decoded = android.util.Base64.decode(text, android.util.Base64.NO_WRAP);
                    showMessage("Base64 Decoded", new String(decoded));
                } catch (Exception e) {
                    showMessage("Error", "Invalid Base64: " + e.getMessage());
                }
            }
        });
        
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }
    
    private String generateHash(String text, String algorithm) {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm.replace("-", ""));
            byte[] hash = md.digest(text.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
    
    // HELPER METHODS
    
    private void showMessage(String title, String message) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        builder.show();
    }
    
    private LinearLayout createCardLayout() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(CARD_BG);
        card.setPadding(20, 20, 20, 20);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 15);
        card.setLayoutParams(params);
        return card;
    }
    
    private void addCard(String title, String content, int color) {
        LinearLayout card = createCardLayout();
        
        TextView titleView = createTextView(title, 16, true);
        titleView.setTextColor(color);
        card.addView(titleView);
        
        TextView contentView = createTextView(content, 12, false);
        contentView.setTextColor(color);
        contentView.setAlpha(0.8f);
        contentView.setPadding(0, 10, 0, 0);
        card.addView(contentView);
        
        mainLayout.addView(card);
    }
    
    private void addToolCard(String title, String desc) {
        LinearLayout card = createCardLayout();
        
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        
        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        textLayout.setLayoutParams(textParams);
        
        TextView titleView = createTextView(title, 14, true);
        titleView.setTextColor(MATRIX_GREEN);
        textLayout.addView(titleView);
        
        TextView descView = createTextView(desc, 11, false);
        descView.setTextColor(MATRIX_GREEN);
        descView.setAlpha(0.7f);
        textLayout.addView(descView);
        
        row.addView(textLayout);
        
        TextView arrow = createTextView(">", 20, true);
        arrow.setTextColor(MATRIX_GREEN);
        row.addView(arrow);
        
        card.addView(row);
        mainLayout.addView(card);
    }
    
    private void addClickableCard(String title, String desc, final Runnable action) {
        LinearLayout card = createCardLayout();
        card.setClickable(true);
        card.setFocusable(true);
        
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        
        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        textLayout.setLayoutParams(textParams);
        
        TextView titleView = createTextView(title, 14, true);
        titleView.setTextColor(MATRIX_GREEN);
        textLayout.addView(titleView);
        
        TextView descView = createTextView(desc, 11, false);
        descView.setTextColor(MATRIX_GREEN);
        descView.setAlpha(0.7f);
        textLayout.addView(descView);
        
        row.addView(textLayout);
        
        TextView arrow = createTextView(">", 20, true);
        arrow.setTextColor(MATRIX_GREEN);
        row.addView(arrow);
        
        card.addView(row);
        mainLayout.addView(card);
    }
    
    private void addSectionTitle(String text) {
        TextView title = createTextView(text, 14, true);
        title.setTextColor(MATRIX_GREEN);
        title.setPadding(0, 15, 0, 10);
        mainLayout.addView(title);
    }
    
    private void addStatItem(LinearLayout parent, String label, String value, int color) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        );
        item.setLayoutParams(params);
        
        TextView valueView = createTextView(value, 24, true);
        valueView.setTextColor(color);
        valueView.setGravity(Gravity.CENTER);
        item.addView(valueView);
        
        TextView labelView = createTextView(label, 10, false);
        labelView.setTextColor(MATRIX_GREEN);
        labelView.setAlpha(0.7f);
        labelView.setGravity(Gravity.CENTER);
        item.addView(labelView);
        
        parent.addView(item);
    }
    
    private TextView createTextView(String text, int size, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(size);
        tv.setTypeface(Typeface.MONOSPACE, bold ? Typeface.BOLD : Typeface.NORMAL);
        return tv;
    }
    
    private void addSpace(LinearLayout parent, int height) {
        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, height
        ));
        parent.addView(space);
    }
}
